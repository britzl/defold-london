EXERCISES:

1. Add scoring. Whenever the player destroys a meteor, she/he is awarded 100 points. This should show in the on-screen score counter.

2. Add a smart bomb that destroys all meteors that are currently incoming. There is an input binding “bomb” bound to the Enter button that you can use.


BONUS EXERCISES:

3. When a meteor is hit, make it split into two smaller parts.

4. Add death. Each time the player dies, a life is subtracted and the game resets. When all lives are gone (shown on screen as well) it is game over.

5. Experiment with effects and anything else you can think about, like different movement schemes, different types of meteors, power-ups or special effects (particles, shaders etc).